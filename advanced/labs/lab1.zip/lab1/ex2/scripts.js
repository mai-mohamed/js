/*
29/12/2019
Mai Mohamed Ghanem
Advanced JS lab 1 exercise ==>2
*/
function StopWatch(){
  var duration = 0;
  this.interval;
  this.count = function(){
     duration++
     console.log(duration)
  };
  this.start = function(){
    this.interval = setInterval(this.count,1000);
  };
  this.stop = function(){
    clearInterval(this.interval);
  };
  this.reset = function(){
    clearInterval(this.interval);
    duration = 0;
    console.log(duration)
  }
}
var myStopWatch = new StopWatch();
//  myStopWatch.start();
//  myStopWatch.stop();
 myStopWatch.reset();
